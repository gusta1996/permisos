<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../phpMailer/src/Exception.php';
require '../phpMailer/src/PHPMailer.php';
require '../phpMailer/src/SMTP.php';

class email
{
    private static $host = 'smtp.gmail.com'; // Servidor SMTP
    private static $SMTPAuth = true; // Habilitar autenticación SMTP
    private static $Username = 'gustasama1996@gmail.com'; // Nombre de usuario SMTP
    private static $Password = 'uiqnypicbspsmncm'; // Contraseña SMTP
    private static $Port = 465; // Puerto SMTP
    private static $SMTPSecure = 'ssl'; // Habilitar SSL
    private static $email = 'gustasama1996@gmail.com'; // Dirección de correo del remitente

    public static function emailSolicitudCreada()
    {
        $mail = new PHPMailer();
        $mail->isSMTP();
/*
        $mail->Host = self::$host; // Servidor SMTP
        $mail->SMTPAuth = self::$SMTPAuth; // Habilitar autenticación SMTP
        $mail->Username = self::$Username; // Nombre de usuario SMTP
        $mail->Password = self::$Password; // Contraseña SMTP
        $mail->Port = self::$Port; // Puerto SMTP
        $mail->SMTPSecure = self::$SMTPSecure; // Habilitar SSL
*/
        $mail->Host = 'smtp.gmail.com'; // Servidor SMTP
        $mail->SMTPAuth = true; // Habilitar autenticación SMTP
        $mail->Username = 'gustasama1996@gmail.com'; // Nombre de usuario SMTP
        $mail->Password = 'uiqnypicbspsmncm'; // Contraseña SMTP
        $mail->Port = 465; // Puerto SMTP
        $mail->SMTPSecure = 'ssl'; // Habilitar SSL

        $mail->setFrom('gustasama1996@gmail.com'); // Dirección de correo del remitente
        $mail->addAddress('www.gszone.org@gmail.com'); // Dirección de correo del destinatario

        $mail->isHTML(true); // Formato de correo en HTML
        $mail->Subject = 'Solicitud de permiso creada'; // asunto
        /*$mensaje = `
        <style>
            .logo {

            }
        </style>
        <div>
            <img width="100%" src="../../..public/images/cabezera.png" />

            <p>Estimada /o {$data['email']}.</p>
            <p>Se ha creado su solicitud de permiso con el ID: {$data['numero_solicitud']}.</p>
            <p>Asegurese que insertar su firma electrónica en el documento, para que se inicio el proceso de aprobacion.</p>
            <p>Saludos cordiales</p>
            
        </div>
        `;*/
        $mail->Body = 'fdsffd'; // mensaje

        if(!$mail->send()) {
            echo 'El mensaje no pudo ser enviado.';
            echo 'Error: ' . $mail->ErrorInfo;
        }
        return;
    }
}
